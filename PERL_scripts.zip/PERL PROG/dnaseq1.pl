use strict;
use warnings;
=pod
my $dnafile="MECR01.1.fsa_nt";
open(my $fh,$dnafile)||die"cannot open file";
my @dna=<$fh>;
close $fh;
=cut
my $dnafile="inputdna.txt";
open(my $fh,$dnafile)||die"cannot open file";
my @dna=<$fh>;
close $fh;

my $dna_str=join('',@dna);
$dna_str=~s/\s//g;
my $string_len =  length( $dna_str );
print"\n\n\t$dna_str";
print"\n\n\n---------------------------------------------------------------------------------------------------------------------------------------------------------------\n\n";
print "\n\nLength of the INPUT String is : \t\t\t$string_len\n";

print"\n\n\n---------------------------------------------------------------------------------------------------------------------------------------------------------------\n\n";
print"/n/n How Many Patterns you want to find ";
chomp(my $cnt=<STDIN>);
my $loopcnt=0;
do{
	print("\n\n\t enter the pattern to be found ");
	chomp(my $pat=<STDIN>);

	if($dna_str=~m/$pat/)
	{
		print"\n\n\t THE GIVEN PATTERN IS FOUND ";
		
		print"\n\n\n---------------------------------------------------------------------------------------------------------------------------------------------------------------\n\n";
		
		my $offset1 = 0;

	my $result = index($dna_str, $pat, $offset1);

	while ($result != -1) {

		print "\n\nFound $pat at \t$result\n";
		print"\n---------------------------------------------------------------------------------------------------------------------------------------------------------------\n";

		$offset1 = $result + 1;
		$result = index($dna_str, $pat, $offset1);

	}
	print"\n\n\tenter the no OF NUCLEOTIDE YOU WANT TO FIND\n\n";
	chomp(my $pos=<STDIN>);
	print"enter the OFFSET OF PAIRS\n\n";
	chomp(my $off=<STDIN>);

	if($pos>length($dna_str))
	{
		print"\n\n NO DATA";
	}
	else
	{
		print"\t ".substr($dna_str,$pos,$off). "\n\n";
		print"\n\n---------------------------------------------------------------------------------------------------------------------------------------------------------------\n\n";

	}
	}	
	else
	{
		print"\n\n\t DNA STRAND DOES NOT CONTAIN THE GIVEN PATTERN ","\n\n";
		print"\n\n\n---------------------------------------------------------------------------------------------------------------------------------------------------------------\n\n";

	}

	
	
	$loopcnt++;
}while($loopcnt<$cnt);





