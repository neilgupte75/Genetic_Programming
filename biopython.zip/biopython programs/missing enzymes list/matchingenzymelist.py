# -*- coding: utf-8 -*-
"""
Created on Tue Jul 31 11:45:31 2018

@author: NEIL
"""

import sys
import Bio
from Bio.Seq import Seq
from Bio import SeqIO
from Bio import Restriction
from Bio.Restriction import *
from Bio.Alphabet.IUPAC import IUPACAmbiguousDNA
import pandas as pd
import csv
a=[]
with open("allenzymelist.txt","r") as f:
    for line in f:
        a=[line.rstrip('\n')for line in f]

print(a)
len(a)

seq=[]
with open("enzymelist.txt","r") as f:
    for line in f:
        seq=[line.rstrip('\n')for line in f]

print(seq)
z=[]
for i in seq: 
    str(i).replace(" ","")
    z.append(i)
    
print(z)
len(z)



c=[]
with open("enzymelist1.txt","r") as f:
    for line in f:
        c=[line.rstrip('\n')for line in f]

print(c)

d=[]
for i in c: 
    str(i).replace(" ","")
    d.append(i)
    
print(d)
len(d)



missing=[]
missing=set(z)-set(a)
print(missing)
len(missing)

common=[]
common=set(z).intersection(set(d))
print(common)
len(common)



