# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-

import Bio
from Bio.Seq import Seq
from Bio import SeqIO
from Bio import Restriction
from Bio.Restriction import *
from Bio.Alphabet.IUPAC import IUPACAmbiguousDNA
Restriction.AbaSI


a=Restriction.EcoRI

amb = IUPACAmbiguousDNA()
my_seq = Seq('AAAAAGAATTCTTTTTTTTGTCAGTCGATGTCAGTGCATGTAGCTGATCGTAGCTAGTCGGAATTCATGCTAGTCGATGCTA', amb)
a.search(my_seq)
a.catalyse(my_seq)
a.is_blunt()
a.is_5overhang()
a.is_3overhang()
EcoRI.elucidate()


rb=Restriction.RestrictionBatch()
rb.add(KpnI)
rb=EcoRI + KpnI + EcoRV+ SmaI + PstI
rb4=Restriction.RestrictionBatch()
rb+= SmaI + PstI
rb|rb4
print(rb)
rb&rb4


rb.elements()
rb.search(my_seq)


#common enzymes used 
len(AllEnzymes)
len(CommOnly)
AllEnzymes.search(my_seq)
Restriction.AllEnzymes.elucidate()
CommOnly.search(my_seq)


 Ana = Analysis(CommOnly, my_seq, linear=False)
 Ana.full()
 Ana.print_that()
 
 Ana.print_as('map')
 Ana.print_that()

 Ana.print_as('number')
 Ana.print_that()
 
 Ana.with_N_sites(1)
 
 Ana.with_N_sites(2)