# -*- coding: utf-8 -*-
"""
Created on Fri Aug 10 11:24:54 2018

@author: NEIL
"""

from Bio.Blast.Applications import NcbiblastpCommandline
from io import StringIO
from Bio.Blast import NCBIXML
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio import SeqIO

from Bio.Alphabet import generic_dna

# Create two sequence files
seq1 = SeqRecord(Seq("CTAGCTAGCTCGATCGATCGATGCTAAGCTTACGTAGCTATCGTACTACGACTGATCGATCGATC"),
                   id="seq1")
seq2 = SeqRecord(Seq("AGCTAGCTAGCTAGCTGTAGCTGATGCTGATCGTAGCTGTAGCTGTAGCGTGATGCTAGCTGTACGTGATGTCGCTAGCTAGTCGACTAGTGCATGCTGACTGTACTGCATGCTATCGATGCGTACTAGCTGATCGTACTACGTAGCTG"),
                   id="seq2")
seq2rev=seq1.seq.complement()

SeqIO.write(seq1, "seq1.fasta", "fasta")
SeqIO.write(seq2, "seq2.fasta", "fasta")

# Run BLAST and parse the output as XML
output = NcbiblastpCommandline(query="seq1.fasta", subject="seq2.fasta", outfmt=5)()[0]
blast_result_record = NCBIXML.read(StringIO(output))

# Print some information on the result
for alignment in blast_result_record.alignments:
    for hsp in alignment.hsps:
        if hsp.expect<1.86735e-02:
             print("****Alignment****")
             print("sequence:", alignment.title)
             print("length:", alignment.length)
             print("e value:", hsp.expect)
             print(hsp.query[0:75] + "...")
             print(hsp.match[0:75] + "...")
             print(hsp.sbjct[0:75] + "...")
                   # print(seq2rev)
'''
seq3=SeqRecord(Seq(match),id="seq3")
SeqIO.write(seq3, "seq3.fasta", "fasta")
print(seq3)
from Bio import Align
aligner = Align.PairwiseAligner()
alignments = aligner.align("AGTC", "TCAG")
for alignment in alignments:
    print(alignment)
    
aligner.algorithm'''    