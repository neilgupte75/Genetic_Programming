# -*- coding: utf-8 -*-
"""
Created on Thu Jul  5 12:00:18 2018

@author: NEIL
"""

import Bio
from Bio.Seq import Seq
from Bio.Alphabet import generic_dna
print (Bio.__version__)
my_seq=Seq('AGTCGAGATGAC',generic_dna)
print(my_seq)
print(my_seq.complement())
print(my_seq.count('A'))
print(my_seq.reverse_complement())