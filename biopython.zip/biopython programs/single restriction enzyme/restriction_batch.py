# -*- coding: utf-8 -*-


import Bio
from Bio.Seq import Seq
from Bio import SeqIO
from Bio import Restriction
from Bio.Restriction import *
from Bio.Alphabet.IUPAC import IUPACAmbiguousDNA
a=Restriction.EcoRI


Restriction.EcoRI.site

amb = IUPACAmbiguousDNA()
my_seq = Seq('AAAAAGAATTCTTTTTTTTGTCAGTCGATGTCAGTGCATGTAGCTGATCGTAGCTAGTCGGAATTCATGCTAGTCGATGCTA', amb)
a.search(my_seq)
a.catalyse(my_seq)
a.is_blunt()
a.is_5overhang()
a.is_3overhang()
a.elucidate()


rb=Restriction.RestrictionBatch()
rb.add(KpnI)
rb=EcoRI + KpnI + EcoRV+ SmaI + PstI
rb4=Restriction.RestrictionBatch()
rb+= SmaI + PstI
rb|rb4
print(rb)
rb&rb4


rb.elements()
rb.search(my_seq)