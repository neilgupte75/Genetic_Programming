# -*- coding: utf-8 -*-
"""
Created on Wed Jul  4 10:56:25 2018

@author: NEIL
"""
import numpy as np
from numpy import array
from numpy import argmax
from keras.utils import to_categorical
from keras.preprocessing.text import Tokenizer
#example
def load_doc(filename):
    file=open(filename,'r')
    text=file.read()
    file.close()
    return text


in_filename="MECR01.1.fsa_nt"
raw_text=load_doc(in_filename)
line=raw_text.split('\n')
    
    

tokenizer=Tokenizer(char_level=True)
tokenizer.fit_on_texts(line)
sequence_of_int=tokenizer.texts_to_sequences_generator(line)
print(sequence_of_int)
#one hot encoder
alpha=['ATCG>']
char_to_int=dict((c,i)for i,c in enumerate(alpha))

int_to_char=dict((c,i)for i,c in enumerate(alpha))

int_encoded=[mapping[char]for char in raw_text]
print(int_encoded)
encoded=to_categorical(raw_text)
print(encoded)

