import sys
import Bio
from Bio.Seq import Seq
from Bio import SeqIO
from Bio import Restriction
from Bio.Restriction import *
from Bio.Alphabet.IUPAC import IUPACAmbiguousDNA
import pandas as pd
fh=open('outputdna.txt','w')
sys.stdout=fh
records=list(SeqIO.parse("test1.fasta","fasta"))
print(len(records))
for i in range(0,1):
    print(records[i].id)
    print("\n")
    print(repr(records[i].seq))
    print("\n")
    my_seq=(records[i].seq) 
    CommOnly.search(my_seq)
    
    
    Ana = Analysis(CommOnly, my_seq, linear=False)
    Ana.full()
     
    Ana.print_as('map')
    Ana.print_that()
    
    Ana.print_as('number')
    Ana.print_that()
    
fh.close()    

        
        
        