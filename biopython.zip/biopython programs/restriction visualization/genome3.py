# -*- coding: utf-8 -*-
"""
Created on Tue Jul 24 11:39:02 2018

@author: NEIL
"""

from reportlab.lib import colors
from reportlab.lib.units import cm
from Bio.Graphics import GenomeDiagram
from Bio import SeqIO
from Bio.Alphabet import IUPAC
from Bio import Restriction
from Bio.Restriction import *
from Bio import SeqFeature
from Bio.Graphics.GenomeDiagram import *
from Bio.SeqFeature import SeqFeature,FeatureLocation,ExactPosition
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq
a=SeqFeature(FeatureLocation(10,11),type="restriction_enzyme")
simple_seq = Seq("GATGGATCCCGCATCGGGATCCATCGCCCGGGATCGAGTCGATCAGCTCCCGGGATCCGGAGCGTACGGTATCGGAATTCGATCGTGAATTCGATCGATCGGAATTC",IUPAC.unambiguous_dna)
simple_seq_r =SeqRecord(simple_seq,id="YP_025292.1", name="HokC",description="toxic membrane protein, small",features=[a])

print(a)
print(simple_seq_r)
print (simple_seq_r[1])

'''AllEnzymes.search(simple_seq)
Ana = Analysis(AllEnzymes,simple_seq, linear=False)
Ana.full()
Ana.print_as('number')
Ana.print_that()
print(simple_seq_r.features)
gdfs= GenomeDiagram.FeatureSet()
for feature in simple_seq_r.features:
    gdfs.add_feature(5,'restrictionenzyme')

for feature in simple_seq_r.features:
    gdfs.add_feature(feature)
    color = colors.lightblue
    gdfs.add_feature(feature, color=color, label=True)
    
    
'''
gd_diagram = GenomeDiagram.Diagram(simple_seq_r.id)
gd_track_for_features = gd_diagram.new_track(1, name="Annotated Features")
gd_feature_set = gd_track_for_features.new_set()    

for site, name, color in [("GAATTC","EcoRI",colors.green),
                      ("CCCGGG","SmaI",colors.orange),
                      ("AAGCTT","HindIII",colors.red),
                          ("GGATCC","BamHI",colors.purple)]:
    index = 0
    while True:
        index  = simple_seq_r.seq.find(site, start=index)
        if index == -1 : break
        feature = SeqFeature(FeatureLocation(index, index+len(site)))
        gd_feature_set.add_feature(feature, color=color, name=name,
                                   label=True, label_size = 10,
                                   label_color=color)
        index+=len(site)

gd_diagram.draw(format="linear", pagesize='A4', fragments=4,
                start=0, end=len(simple_seq_r))
gd_diagram.write("plasmidneilnice.pdf", "PNG")



gd_diagram.draw(format="circular", circular=True, pagesize=(20*cm,20*cm),
                start=0, end=len(simple_seq_r), circle_core = 0.5)
gd_diagram.write("plasmid_circular_nice.pdf", "PNG")