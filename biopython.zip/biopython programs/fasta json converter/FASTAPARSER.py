# -*- coding: utf-8 -*-
"""
Created on Mon Aug  6 11:14:31 2018

@author: NEIL
"""


from reportlab.lib import colors
from reportlab.lib.units import cm
from Bio.Graphics import GenomeDiagram
from Bio import SeqIO
import pandas as pd
import Bio
import json
records=list(SeqIO.parse("test1.fasta","fasta"))
print(len(records))
b=[]
for i in range(0,56587):
    print(records[i].id)
    print("\n")
    print(repr(records[i].seq))
    print("\n")
    b.append([records[i].id,records[i].name,records[i].description,records[i].name,repr(records[i].seq)])

print(b)


a=json.dumps(b)
print(a)