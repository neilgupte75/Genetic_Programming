# -*- coding: utf-8 -*-
"""
Created on Fri Jul  6 14:23:15 2018

@author: NEIL
"""
import Bio
from Bio.Seq import Seq
from Bio import SeqIO
from Bio import Restriction
from Bio.Alphabet.IUPAC import IUPACAmbiguousDNA
Restriction.EcoRI


Restriction.EcoRI.site

amb = IUPACAmbiguousDNA()
my_seq = Seq('AAAAAGAATTCTTTTTTTT', amb)
Restriction.EcoRI.search(my_seq)
Restriction.EcoRI.catalyse(my_seq)

dir(Restriction)
print(Restriction.enzymedict.)